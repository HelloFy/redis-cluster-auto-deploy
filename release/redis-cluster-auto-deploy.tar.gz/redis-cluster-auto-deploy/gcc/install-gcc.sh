#!/bin/bash

rpm -ivh ppl-0.10.2-11.el6.x86_64.rpm --nodeps --force
rpm -ivh cloog-ppl-0.15.7-1.2.el6.x86_64.rpm --nodeps --force
rpm -ivh mpfr-2.4.1-6.el6.x86_64.rpm --nodeps --force
rpm -ivh cpp-4.4.7-17.el6.x86_64.rpm --nodeps --force
rpm -ivh kernel-headers-2.6.32-642.4.2.el6.x86_64.rpm --nodeps --force
rpm -ivh glibc-headers-2.12-1.192.el6.x86_64.rpm --nodeps --force
rpm -ivh glibc-devel-2.12-1.192.el6.x86_64.rpm --nodeps --force
rpm -ivh libgomp-4.4.7-17.el6.x86_64.rpm --nodeps --force
rpm -ivh gcc-4.4.7-17.el6.x86_64.rpm --nodeps --force
